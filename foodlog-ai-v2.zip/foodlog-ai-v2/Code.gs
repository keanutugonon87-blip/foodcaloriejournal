/**
 * FoodLog AI — Server (Google Apps Script)
 * ------------------------------------------------------------
 * Data lives in a Google Sheet (acts as the database). This file
 * parses natural-language food questions, estimates calories +
 * macros from a local knowledge base, persists entries to the
 * Sheet, and aggregates data for the Insights dashboard.
 *
 * SETUP: bind this script to a Google Sheet (Extensions > Apps
 * Script from inside the Sheet), then Deploy > New deployment >
 * Web app. See README.md for full steps.
 * ------------------------------------------------------------
 */

const SHEET_NAME = "FoodLog";
const HEADERS = [
  "Timestamp", "Date (ISO)", "Date (Label)", "Food", "Emoji",
  "Quantity", "Calories Min", "Calories Max",
  "Protein (g)", "Carbs (g)", "Fat (g)", "Recognized",
];

/* ================= Web app entry point ================= */

function doGet(e) {
  return HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("FoodLog AI")
    .addMetaTag("viewport", "width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/* ================= Sheet access ================= */

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight("bold");
  }
  return sheet;
}

function getAllRows_() {
  const sheet = getSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const values = sheet.getRange(2, 1, lastRow - 1, HEADERS.length).getValues();
  return values.map((r) => ({
    timestamp: r[0],
    dateISO: r[1],
    dateLabel: r[2],
    food: r[3],
    emoji: r[4],
    qtyLabel: r[5],
    min: Number(r[6]) || 0,
    max: Number(r[7]) || 0,
    protein: Number(r[8]) || 0,
    carbs: Number(r[9]) || 0,
    fat: Number(r[10]) || 0,
    recognized: r[11],
  }));
}

function appendEntries_(dateISO, dateLabel, items) {
  const sheet = getSheet_();
  const now = new Date();
  const rows = items.map((it) => [
    now, dateISO, dateLabel, it.label, it.emoji, it.qtyLabel || "",
    it.min, it.max, it.protein || 0, it.carbs || 0, it.fat || 0,
    it.recognized ? "Yes" : "No",
  ]);
  sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, HEADERS.length).setValues(rows);
}

function clearHistory_() {
  const sheet = getSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow > 1) {
    sheet.getRange(2, 1, lastRow - 1, HEADERS.length).clearContent();
  }
}

/* ================= Food knowledge base =================
   unit: "count" -> range/macros apply per piece/cup/slice/etc (quantity is a plain multiplier)
   unit: "100g"  -> range/macros apply per 100g (quantity in grams is converted)
   range: [min, max] calories for ONE base unit. macros are single-value grams for ONE base unit.
========================================================== */
const FOOD_DB = [
  { names: ["white rice", "cooked rice", "steamed rice", "rice"], emoji: "🍚", unit: "count", baseLabel: "cup, cooked", range: [200, 240], macros: [4, 45, 0] },
  { names: ["brown rice"], emoji: "🍚", unit: "count", baseLabel: "cup, cooked", range: [215, 250], macros: [5, 45, 2] },
  { names: ["fried rice"], emoji: "🍛", unit: "count", baseLabel: "cup", range: [230, 280], macros: [6, 40, 7] },
  { names: ["fried chicken"], emoji: "🍗", unit: "100g", baseLabel: "100 g", range: [260, 330], macros: [19, 10, 17] },
  { names: ["grilled chicken", "chicken breast"], emoji: "🍗", unit: "100g", baseLabel: "100 g", range: [160, 180], macros: [31, 0, 4] },
  { names: ["chicken thigh"], emoji: "🍗", unit: "100g", baseLabel: "100 g", range: [200, 240], macros: [24, 0, 12] },
  { names: ["chicken wing", "chicken wings"], emoji: "🍗", unit: "count", baseLabel: "piece", range: [80, 105], macros: [8, 0, 6] },
  { names: ["beef steak", "steak"], emoji: "🥩", unit: "100g", baseLabel: "100 g", range: [250, 290], macros: [26, 0, 18] },
  { names: ["ground beef", "beef mince"], emoji: "🥩", unit: "100g", baseLabel: "100 g", range: [215, 250], macros: [26, 0, 15] },
  { names: ["pork chop"], emoji: "🍖", unit: "100g", baseLabel: "100 g", range: [230, 270], macros: [25, 0, 15] },
  { names: ["bacon"], emoji: "🥓", unit: "count", baseLabel: "slice", range: [40, 50], macros: [3, 0, 3] },
  { names: ["sausage", "hot dog"], emoji: "🌭", unit: "count", baseLabel: "link/piece", range: [90, 160], macros: [6, 2, 12] },
  { names: ["salmon"], emoji: "🐟", unit: "100g", baseLabel: "100 g", range: [205, 230], macros: [22, 0, 13] },
  { names: ["tuna", "canned tuna"], emoji: "🐟", unit: "100g", baseLabel: "100 g", range: [110, 130], macros: [25, 0, 1] },
  { names: ["shrimp", "prawns"], emoji: "🍤", unit: "100g", baseLabel: "100 g", range: [85, 105], macros: [20, 0, 1] },
  { names: ["tofu"], emoji: "🧊", unit: "100g", baseLabel: "100 g", range: [70, 90], macros: [8, 2, 4] },
  { names: ["egg", "eggs", "boiled egg", "fried egg"], emoji: "🥚", unit: "count", baseLabel: "large egg", range: [70, 90], macros: [6, 1, 5] },
  { names: ["scrambled eggs"], emoji: "🥚", unit: "count", baseLabel: "egg, scrambled", range: [90, 100], macros: [6, 1, 7] },
  { names: ["bread", "white bread", "toast"], emoji: "🍞", unit: "count", baseLabel: "slice", range: [70, 95], macros: [3, 14, 1] },
  { names: ["brown bread", "whole wheat bread"], emoji: "🍞", unit: "count", baseLabel: "slice", range: [70, 90], macros: [4, 13, 1] },
  { names: ["bagel"], emoji: "🥯", unit: "count", baseLabel: "piece", range: [230, 290], macros: [9, 48, 1] },
  { names: ["pasta", "spaghetti", "noodles"], emoji: "🍝", unit: "count", baseLabel: "cup, cooked", range: [190, 225], macros: [7, 42, 1] },
  { names: ["instant noodles", "ramen noodles"], emoji: "🍜", unit: "count", baseLabel: "pack", range: [380, 420], macros: [8, 52, 15] },
  { names: ["ramen"], emoji: "🍜", unit: "count", baseLabel: "bowl", range: [450, 550], macros: [18, 60, 16] },
  { names: ["pho"], emoji: "🍜", unit: "count", baseLabel: "bowl", range: [350, 450], macros: [22, 55, 6] },
  { names: ["pizza"], emoji: "🍕", unit: "count", baseLabel: "slice", range: [250, 350], macros: [11, 33, 10] },
  { names: ["burger", "hamburger", "cheeseburger"], emoji: "🍔", unit: "count", baseLabel: "burger", range: [350, 550], macros: [25, 35, 22] },
  { names: ["sandwich"], emoji: "🥪", unit: "count", baseLabel: "sandwich", range: [300, 500], macros: [18, 35, 15] },
  { names: ["taco"], emoji: "🌮", unit: "count", baseLabel: "taco", range: [150, 250], macros: [9, 15, 9] },
  { names: ["burrito"], emoji: "🌯", unit: "count", baseLabel: "burrito", range: [400, 700], macros: [22, 60, 18] },
  { names: ["sushi roll", "sushi"], emoji: "🍣", unit: "count", baseLabel: "roll (~8 pcs)", range: [300, 350], macros: [10, 50, 6] },
  { names: ["dumplings", "gyoza"], emoji: "🥟", unit: "count", baseLabel: "3 pieces", range: [150, 200], macros: [6, 22, 5] },
  { names: ["french fries", "fries"], emoji: "🍟", unit: "count", baseLabel: "cup/serving", range: [300, 400], macros: [4, 45, 16] },
  { names: ["potato", "baked potato"], emoji: "🥔", unit: "count", baseLabel: "medium potato", range: [160, 175], macros: [4, 37, 0] },
  { names: ["mashed potato", "mashed potatoes"], emoji: "🥔", unit: "count", baseLabel: "cup", range: [210, 240], macros: [4, 35, 8] },
  { names: ["sweet potato"], emoji: "🍠", unit: "count", baseLabel: "medium", range: [100, 120], macros: [2, 24, 0] },
  { names: ["broccoli"], emoji: "🥦", unit: "count", baseLabel: "cup", range: [50, 55], macros: [4, 10, 0] },
  { names: ["carrot", "carrots"], emoji: "🥕", unit: "count", baseLabel: "medium", range: [25, 35], macros: [1, 6, 0] },
  { names: ["spinach"], emoji: "🥬", unit: "count", baseLabel: "cup", range: [7, 10], macros: [1, 1, 0] },
  { names: ["salad", "green salad", "side salad"], emoji: "🥗", unit: "count", baseLabel: "bowl", range: [50, 180], macros: [3, 10, 4] },
  { names: ["soup"], emoji: "🍲", unit: "count", baseLabel: "bowl", range: [150, 260], macros: [9, 20, 6] },
  { names: ["curry"], emoji: "🍛", unit: "count", baseLabel: "bowl", range: [350, 450], macros: [18, 30, 20] },
  { names: ["stir fry"], emoji: "🥘", unit: "count", baseLabel: "bowl", range: [300, 400], macros: [20, 25, 15] },
  { names: ["black beans", "beans"], emoji: "🫘", unit: "count", baseLabel: "cup, cooked", range: [220, 230], macros: [15, 40, 1] },
  { names: ["lentils"], emoji: "🥣", unit: "count", baseLabel: "cup, cooked", range: [220, 230], macros: [18, 40, 1] },
  { names: ["oatmeal", "porridge"], emoji: "🥣", unit: "count", baseLabel: "cup, cooked", range: [150, 170], macros: [5, 27, 3] },
  { names: ["cereal"], emoji: "🥣", unit: "count", baseLabel: "cup, with milk", range: [150, 220], macros: [6, 30, 3] },
  { names: ["pancake", "pancakes"], emoji: "🥞", unit: "count", baseLabel: "pancake", range: [80, 90], macros: [2, 15, 2] },
  { names: ["waffle", "waffles"], emoji: "🧇", unit: "count", baseLabel: "waffle", range: [150, 220], macros: [4, 25, 5] },
  { names: ["banana"], emoji: "🍌", unit: "count", baseLabel: "medium banana", range: [90, 120], macros: [1, 27, 0] },
  { names: ["apple"], emoji: "🍎", unit: "count", baseLabel: "medium apple", range: [80, 100], macros: [0, 25, 0] },
  { names: ["orange"], emoji: "🍊", unit: "count", baseLabel: "medium orange", range: [60, 80], macros: [1, 15, 0] },
  { names: ["mango"], emoji: "🥭", unit: "count", baseLabel: "cup, sliced", range: [150, 165], macros: [1, 25, 1] },
  { names: ["grapes"], emoji: "🍇", unit: "count", baseLabel: "cup", range: [60, 105], macros: [1, 16, 0] },
  { names: ["watermelon"], emoji: "🍉", unit: "count", baseLabel: "cup", range: [45, 50], macros: [1, 11, 0] },
  { names: ["strawberries", "strawberry"], emoji: "🍓", unit: "count", baseLabel: "cup", range: [45, 55], macros: [1, 11, 0] },
  { names: ["avocado"], emoji: "🥑", unit: "count", baseLabel: "whole avocado", range: [230, 320], macros: [3, 12, 21] },
  { names: ["yogurt"], emoji: "🥣", unit: "count", baseLabel: "cup", range: [110, 150], macros: [9, 12, 3] },
  { names: ["milk"], emoji: "🥛", unit: "count", baseLabel: "cup", range: [100, 150], macros: [8, 12, 5] },
  { names: ["cheese"], emoji: "🧀", unit: "count", baseLabel: "slice", range: [60, 110], macros: [6, 1, 8] },
  { names: ["butter"], emoji: "🧈", unit: "count", baseLabel: "tbsp", range: [90, 100], macros: [0, 0, 11] },
  { names: ["peanut butter"], emoji: "🥜", unit: "count", baseLabel: "tbsp", range: [90, 95], macros: [4, 3, 8] },
  { names: ["almonds", "nuts"], emoji: "🥜", unit: "count", baseLabel: "small handful (1 oz)", range: [160, 170], macros: [6, 6, 14] },
  { names: ["hummus"], emoji: "🧆", unit: "count", baseLabel: "2 tbsp", range: [70, 80], macros: [2, 6, 5] },
  { names: ["guacamole"], emoji: "🥑", unit: "count", baseLabel: "2 tbsp", range: [50, 60], macros: [1, 3, 5] },
  { names: ["popcorn"], emoji: "🍿", unit: "count", baseLabel: "cup", range: [30, 55], macros: [1, 6, 2] },
  { names: ["chips", "potato chips"], emoji: "🥔", unit: "count", baseLabel: "small handful (1 oz)", range: [150, 160], macros: [2, 15, 10] },
  { names: ["chocolate", "chocolate bar"], emoji: "🍫", unit: "count", baseLabel: "bar", range: [200, 250], macros: [3, 25, 13] },
  { names: ["cookie", "cookies"], emoji: "🍪", unit: "count", baseLabel: "cookie", range: [50, 100], macros: [1, 12, 4] },
  { names: ["donut", "doughnut"], emoji: "🍩", unit: "count", baseLabel: "donut", range: [190, 300], macros: [3, 30, 15] },
  { names: ["muffin"], emoji: "🧁", unit: "count", baseLabel: "muffin", range: [300, 450], macros: [5, 55, 12] },
  { names: ["croissant"], emoji: "🥐", unit: "count", baseLabel: "croissant", range: [230, 280], macros: [5, 26, 12] },
  { names: ["ice cream"], emoji: "🍦", unit: "count", baseLabel: "cup", range: [270, 330], macros: [5, 32, 15] },
  { names: ["granola bar"], emoji: "🍫", unit: "count", baseLabel: "bar", range: [120, 200], macros: [3, 25, 5] },
  { names: ["protein shake"], emoji: "🥤", unit: "count", baseLabel: "shake", range: [150, 250], macros: [25, 8, 3] },
  { names: ["coffee", "black coffee"], emoji: "☕", unit: "count", baseLabel: "cup", range: [2, 5], macros: [0, 0, 0] },
  { names: ["latte", "cappuccino"], emoji: "☕", unit: "count", baseLabel: "cup", range: [120, 190], macros: [7, 12, 6] },
  { names: ["tea"], emoji: "🍵", unit: "count", baseLabel: "cup", range: [0, 5], macros: [0, 0, 0] },
  { names: ["orange juice", "juice"], emoji: "🧃", unit: "count", baseLabel: "cup", range: [110, 120], macros: [1, 26, 0] },
  { names: ["soda", "cola", "soft drink"], emoji: "🥤", unit: "count", baseLabel: "can", range: [140, 150], macros: [0, 39, 0] },
  { names: ["beer"], emoji: "🍺", unit: "count", baseLabel: "can/bottle", range: [150, 200], macros: [2, 13, 0] },
  { names: ["wine"], emoji: "🍷", unit: "count", baseLabel: "glass", range: [120, 130], macros: [0, 4, 0] },
];

const UNIT_ALIASES = { g: ["g", "gram", "grams"], kg: ["kg", "kilogram", "kilograms"] };
const WORD_NUMBERS = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, half: 0.5 };

/* ================= Matching + parsing ================= */

function findFood_(rawName) {
  const name = rawName.trim().toLowerCase().replace(/[.!?]+$/, "");
  if (!name) return null;

  for (const item of FOOD_DB) {
    if (item.names.indexOf(name) !== -1) return item;
  }

  let best = null, bestLen = 0;
  for (const item of FOOD_DB) {
    for (const alias of item.names) {
      if (name.indexOf(alias) !== -1 && alias.length > bestLen) {
        best = item;
        bestLen = alias.length;
      }
    }
  }
  if (best) return best;

  let bestShort = null, bestShortLen = Infinity;
  for (const item of FOOD_DB) {
    for (const alias of item.names) {
      if (alias.indexOf(name) !== -1 && alias.length < bestShortLen) {
        bestShort = item;
        bestShortLen = alias.length;
      }
    }
  }
  return bestShort;
}

const QTY_UNIT_RE = /^(\d+(?:\.\d+)?|a|an|one|two|three|four|five|six|seven|eight|nine|ten|half)\s*(cups?|pieces?|pcs?|pc|g|grams?|kg|kilograms?|servings?|serving|bowls?|bowl|slices?|slice|oz|ounces?|cans?|glass(?:es)?|links?|handfuls?)?\s*(?:of\s+)?/i;

function parseClause_(clause) {
  const m = clause.match(QTY_UNIT_RE);
  let quantity = 1, unitRaw = null, foodText = clause.trim();
  if (m) {
    const qToken = m[1] ? m[1].toLowerCase() : null;
    quantity = qToken ? (WORD_NUMBERS[qToken] !== undefined ? WORD_NUMBERS[qToken] : parseFloat(qToken)) : 1;
    if (isNaN(quantity)) quantity = 1;
    unitRaw = m[2] ? m[2].toLowerCase().replace(/s$/, "") : null;
    foodText = clause.slice(m[0].length).trim();
  }
  return { quantity, unitRaw, foodText: foodText || clause.trim() };
}

function isGramUnit_(unitRaw) {
  if (!unitRaw) return false;
  return UNIT_ALIASES.g.indexOf(unitRaw) !== -1 || UNIT_ALIASES.g.indexOf(unitRaw + "s") !== -1;
}
function isKgUnit_(unitRaw) {
  if (!unitRaw) return false;
  return UNIT_ALIASES.kg.indexOf(unitRaw) !== -1 || UNIT_ALIASES.kg.indexOf(unitRaw + "s") !== -1;
}

function splitClauses_(text) {
  const cleaned = text
    .replace(/\btoday\b/gi, "").replace(/\byesterday\b/gi, "")
    .replace(/\bi ate\b/gi, "").replace(/\bi had\b/gi, "")
    .replace(/^\s*[,.]/, "").trim();
  return cleaned.split(/,| and |\+|;/gi).map((s) => s.trim()).filter(Boolean);
}

function estimateClause_(clause) {
  const { quantity, unitRaw, foodText } = parseClause_(clause);
  const food = findFood_(foodText);

  if (!food) {
    return {
      label: foodText.charAt(0).toUpperCase() + foodText.slice(1),
      qtyLabel: quantity !== 1 ? quantity + "×" : null,
      emoji: "🍽️",
      min: Math.round(200 * quantity),
      max: Math.round(300 * quantity),
      protein: 0, carbs: 0, fat: 0,
      recognized: false,
    };
  }

  let min, max, protein, carbs, fat, qtyLabel;
  if (food.unit === "100g" && (isGramUnit_(unitRaw) || isKgUnit_(unitRaw))) {
    const grams = isKgUnit_(unitRaw) ? quantity * 1000 : quantity;
    const factor = grams / 100;
    min = Math.round(food.range[0] * factor);
    max = Math.round(food.range[1] * factor);
    protein = Math.round(food.macros[0] * factor);
    carbs = Math.round(food.macros[1] * factor);
    fat = Math.round(food.macros[2] * factor);
    qtyLabel = isKgUnit_(unitRaw) ? quantity + " kg" : grams + " g";
  } else {
    min = Math.round(food.range[0] * quantity);
    max = Math.round(food.range[1] * quantity);
    protein = Math.round(food.macros[0] * quantity);
    carbs = Math.round(food.macros[1] * quantity);
    fat = Math.round(food.macros[2] * quantity);
    qtyLabel = quantity !== 1 ? quantity + " × " + food.baseLabel : food.baseLabel;
  }

  return {
    label: food.names[0].replace(/\b\w/g, (c) => c.toUpperCase()),
    qtyLabel, emoji: food.emoji, min, max, protein, carbs, fat, recognized: true,
  };
}

/* ================= Date handling (client supplies "today") ================= */

const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

function parseISO_(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}
function toISO_(d) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
  return y + "-" + m + "-" + day;
}
function labelForDate_(d) {
  return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}
function todayISO_() {
  return toISO_(new Date());
}

function detectDate_(text, todayISO) {
  const lower = text.toLowerCase();
  const now = parseISO_(todayISO);

  if (/\byesterday\b/.test(lower)) {
    const d = new Date(now); d.setDate(d.getDate() - 1); return d;
  }
  if (/\btoday\b/.test(lower)) return now;

  for (let i = 0; i < MONTHS.length; i++) {
    const re = new RegExp("\\b" + MONTHS[i].slice(0, 3) + "[a-z]*\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b", "i");
    const m = lower.match(re);
    if (m) {
      const d = new Date(now.getFullYear(), i, parseInt(m[1], 10));
      if (d > now) d.setFullYear(d.getFullYear() - 1);
      return d;
    }
  }

  const slash = lower.match(/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/);
  if (slash) {
    const mo = parseInt(slash[1], 10) - 1, day = parseInt(slash[2], 10);
    const year = slash[3] ? parseInt(slash[3].length === 2 ? "20" + slash[3] : slash[3], 10) : now.getFullYear();
    return new Date(year, mo, day);
  }
  return now;
}

function isQuery_(text) {
  return /\b(what did i eat|show me|how many calories did i (eat|have)|what have i eaten|food log for|log for)\b/i.test(text);
}

/* ================= Public API (called from client via google.script.run) ================= */

/**
 * Main entry point for the chat composer. Detects whether the
 * message is a new food entry or a lookup of a past date, and
 * returns everything the client needs to render + refresh state.
 */
function submitFoodEntry(text, clientTodayISO) {
  const todayISO = clientTodayISO || todayISO_();

  if (isQuery_(text)) {
    const dateObj = detectDate_(text, todayISO);
    const dateISO = toISO_(dateObj);
    const rows = getAllRows_().filter((r) => r.dateISO === dateISO);
    return {
      type: "query",
      dateLabel: labelForDate_(dateObj),
      items: rows.map((r) => ({ label: r.food, emoji: r.emoji, qtyLabel: r.qtyLabel, min: r.min, max: r.max })),
      dashboard: getDashboardData(todayISO),
    };
  }

  const clauses = splitClauses_(text);
  if (!clauses.length) {
    return { type: "empty", dashboard: getDashboardData(todayISO) };
  }

  const items = clauses.map(estimateClause_);
  const anyUnrecognized = items.some((i) => !i.recognized);
  const dateObj = detectDate_(text, todayISO);
  const dateISO = toISO_(dateObj);
  const dateLabel = labelForDate_(dateObj);

  appendEntries_(dateISO, dateLabel, items);

  return {
    type: "logged",
    dateLabel,
    items,
    note: anyUnrecognized
      ? "One or more items weren't in the local food table, so those are rough placeholder estimates. Try naming the dish more specifically for a tighter range."
      : null,
    dashboard: getDashboardData(todayISO),
  };
}

/** Full dashboard payload: log table (grouped), today's total, 7-day trend, today's macros, quick stats. */
function getDashboardData(clientTodayISO) {
  const todayISO = clientTodayISO || todayISO_();
  const rows = getAllRows_();

  // Group by date, most recent first
  const byDate = {};
  rows.forEach((r) => {
    if (!byDate[r.dateISO]) byDate[r.dateISO] = [];
    byDate[r.dateISO].push(r);
  });
  const dateKeys = Object.keys(byDate).sort().reverse();
  const log = dateKeys.map((dateISO) => {
    const dayRows = byDate[dateISO];
    const dayMin = dayRows.reduce((s, r) => s + r.min, 0);
    const dayMax = dayRows.reduce((s, r) => s + r.max, 0);
    return { dateISO, dateLabel: dayRows[0].dateLabel, rows: dayRows, dayMin, dayMax };
  });

  const todayRows = byDate[todayISO] || [];
  const todayTotal = {
    min: todayRows.reduce((s, r) => s + r.min, 0),
    max: todayRows.reduce((s, r) => s + r.max, 0),
  };
  const macroToday = {
    protein: todayRows.reduce((s, r) => s + r.protein, 0),
    carbs: todayRows.reduce((s, r) => s + r.carbs, 0),
    fat: todayRows.reduce((s, r) => s + r.fat, 0),
  };

  // 7-day trend ending today (client-local)
  const trend = [];
  const todayDateObj = parseISO_(todayISO);
  for (let i = 6; i >= 0; i--) {
    const d = new Date(todayDateObj);
    d.setDate(d.getDate() - i);
    const iso = toISO_(d);
    const dayRows = byDate[iso] || [];
    const min = dayRows.reduce((s, r) => s + r.min, 0);
    const max = dayRows.reduce((s, r) => s + r.max, 0);
    trend.push({ dateISO: iso, label: d.toLocaleDateString("en-US", { weekday: "short" }), avg: Math.round((min + max) / 2) });
  }

  // Quick stats
  const daysLogged = dateKeys.length;
  let avgDailyCalories = 0;
  if (daysLogged) {
    const totalAvg = log.reduce((s, d) => s + (d.dayMin + d.dayMax) / 2, 0);
    avgDailyCalories = Math.round(totalAvg / daysLogged);
  }
  const foodCounts = {};
  rows.forEach((r) => { foodCounts[r.food] = (foodCounts[r.food] || 0) + 1; });
  let topFood = "—", topCount = 0;
  Object.keys(foodCounts).forEach((f) => {
    if (foodCounts[f] > topCount) { topFood = f; topCount = foodCounts[f]; }
  });
  let streak = 0;
  for (let i = 0; ; i++) {
    const d = new Date(todayDateObj); d.setDate(d.getDate() - i);
    if (byDate[toISO_(d)]) streak++; else break;
  }

  return { log, todayTotal, macroToday, trend, stats: { daysLogged, avgDailyCalories, topFood, streak } };
}

/** Called from the client's "Clear history" button. */
function clearHistoryAndRefresh(clientTodayISO) {
  clearHistory_();
  return getDashboardData(clientTodayISO || todayISO_());
}
